clear;
clc;
close all;

alpha=0.01227;
beta=0.145e-3;
grav=9.81;
c=2060;
r0=6.371e06;
u=1.25;%0.2;%9.52551;



h(1)=0;
h(2)=3048;
dt=0.01;
p(1)=0;
% p(2)=p(1);
% p(3)=10000;
% p(2)=1;
% p(3)=11.5;
% p(4)=p(3);
% p(5)=10000;
% p(2)=0.05;
 
p(5)=10000;
minim=100000;

for auxi=0:dt:5
    p(2)=auxi;
    p2limit=0;
    p(3)=p(2);
    
    while p2limit==0

       p(3)=p(3)+dt;
       p(4)=p(3);

    stop=0;
        while stop==0
            p(2*2)=p(2*2)+dt;

            m(2)=20;
            h(1)=0;
            v(1)=0;
            h(2)=3048;
            v(2)=0;
            m(1)=m(2)+(p(2)+p(4)-p(3))*u;

            for i=1:(size(p,2)-1)
                if mod(i,2)==0
                    uin=0;
                else
                    uin=u;
                end
                for t=p(i):dt:p(i+1)
                    m(3)=m(1)-uin*dt;
                    v(3)=v(1)+dt.*(1./m(1).*(c.*uin-alpha.*v(1).^2.*(1-2.252.*10.^(-5).*h(1)).^4.256)-grav.*(r0^2)./(r0+h(1)).^2);%(1./m(1).*(c.*u-alpha.*v(1).^2)-grav);
                    h(3)=h(1)+dt*v(1);
                    aux=h(1);
                    m(1)=m(3);
                    v(1)=v(3);    
                    h(1)=h(3);

                    if aux>h(3) && i==4
                       break;
                    end

                    if aux>h(3) && i==2
                        disp('aici mergem in jos');
                        p2limit=1;
                    end

                end
                if h(1)>h(2)
                    disp('ies de tot');
                    stop=1;
                    if (p(4)-p(3)+p(2))<minim
                        minim=(p(4)-p(3)+p(2));
                        ms(1)=p(2);
                        ms(2)=p(3);
                        ms(3)=p(4);
                        ms(4)=t;
                    end
                    break;
                end
            end
        end
    end
end
