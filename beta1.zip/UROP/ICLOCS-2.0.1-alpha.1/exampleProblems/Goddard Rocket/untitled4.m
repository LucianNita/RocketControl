clear;
clc;
close all;

alpha=0.01227;
beta=0.145e-3;
grav=9.81;
c=2060;
r0=6.371e06;
u=1.25;%0.2;%9.52551;
h(1)=0;
h(2)=3048;
dt=0.01;

p(1)=0;
p(2)=2.59;
p(3)=10.07;
p(4)=11.82;
p(5)=26.97;


m(2)=20;
h(1)=0;
v(1)=0;
h(2)=3048;
v(2)=0;
m(1)=m(2)+(p(4)-p(3)+p(2))*u;
hs=[0];
vs=[0];
ms=[m(1)];
ts=[0];
us=[u];
% plot (0,h(1),'x');
% hold on;

for i=1:(size(p,2)-1)
    if mod(i,2)==0
        ui=0;
    else
        ui=u;
    end
    for t=p(i):dt:p(i+1)
        m(3)=m(1)-ui*dt;
        v(3)=v(1)+dt.*(1./m(1).*(c.*ui-alpha.*v(1).^2.*(1-2.252.*10.^(-5).*h(1)).^4.256)-grav.*(r0^2)./(r0+h(1)).^2);%(1./m(1).*(c.*u-alpha.*v(1).^2)-grav);
        h(3)=h(1)+dt*v(1);
        m(1)=m(3);
        v(1)=v(3);
        h(1)=h(3);
%         plot(t+dt,h(1),'x');
        hs=[hs,h(3)];
        vs=[vs,v(3)];
        ms=[ms,m(3)];
        ts=[ts,t+dt];
        if ui==u
            us=[us,u];
        else
            us=[us,0];
        end
    end
end

    figure();
    plot (ts,hs,'ro');
    xlabel('Time (s)');
    ylabel('States - Altitude (m)');
    figure();
    plot (ts,vs,'ro');
    xlabel('Time (s)');
    ylabel('States - Velocity (m/s)');
    figure();
    plot (ts,ms,'ro');
    xlabel('Time (s)');
    ylabel('States - Total mass (kg)');
    figure();
    plot (ts,us,'bo-');
    xlabel('Time (s)');
    ylabel('Control Input-Thrust*Isp (N*s^3/m)');
