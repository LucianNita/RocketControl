# ICLOCS
Imperial College London Optimal Control Software (ICLOCS)

http://www.ee.ic.ac.uk/ICLOCS/
