function tau = normalizeT( T, t0,tf )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

    tau = ((1-(-1))*T-(t0+tf)) /(tf-t0);
end

